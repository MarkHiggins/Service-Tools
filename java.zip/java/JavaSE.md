



# 第一章 Java简介

## 第一节  课程简介

### 【基础技能】

* 掌握互联网编程基础核心知识
* 掌握新版java基础语法和数据类型
* 掌握多种循环和静态`static`语法
* 掌握接口、继承、抽象等核心`OOP`思想
* 掌握异常`Exception`体系和自定义异常
* 掌握`Collection`集合框架体系基础

### 【中级技能】

* 掌握`List/Set/Map`等核心数据结构
* 掌握`Iterator`迭代器和自定义排序接口
* 掌握Java操作`File`常用操作
* 掌握IO流`Input、Output Stream`流
* 掌握常⻅`Object、Math、String`等核心类
* 掌握枚举`Enum`和时间日期`LocalDate`使用 

## 第二节  课程开发环境 ： Window | Mac | Linux + IDEA ｜ Eclipse + JDK8~13 + VSCODE

**【提问技巧】**

1. 描述遇到的问题
2. 操作的上下文
3. 截图错误日志或者代码

### 简介：讲解java的编程历史，jdk、jre、JVM区别和概述

1. 计算机语言发展历史

* 第一代 计算机语言：01010100010111000 
* 第二代 汇编语言[^ 00000011写成汇编语言就是 ADD，只要还原成二进制， 汇编语言就可以被 CPU 直接执行，所以它是最底层的低级语言]
* 第三代 高级语言
  * 面向过程：c，Fortran 。。。
  * 面向对象：c++，java，c#。。。

2. JAVA 语言历史近二十年
   * 来自Sun公司，全称 Stanford University Network
   * 1990年12月，sun成立了一个“Green Team”, java之父——Jeams Golsling
   * 1996年 JDK1.0版本
   * 。。。
   * 2009年 甲⻣文以现金收购Sun公司
   * 2011年 Oracle公司发布了JDK7
   * 2014年，Oracle公司发布了JDK8
   * 2017年 JDK9
   * 2018-03 JDK10
   * 2018-09 JDK11
3. Java版本介绍
   * JavaSE，即Java标准版（以前简写J2SE）Java技术核心和基础，是J2ME和J2EE编程的基础
   * JavaEE，即Java企业版（以前简写J2EE）java技术中应用应用最广泛的部分
   * JavaME，即Java微型版（以前简写J2ME）,主要用于移动设备
4. JVM、JRE、JDK关系？
   * JVM：Java Virtual Machine Java 虚拟机，简单看成一个操作系统，java程序会首先被编译为.class的字节码，根据字节码指令进行识别并调用上层操作系统
   * JRE：Java Runtime Environment java 运行时环境, 是整个 Java 程序运行的核心
   * JDK：Java Development Kit 是我们的开发工具包，它集成了 JRE, 是整个 Java 开发的核心
   * 总结：
     + JRE = 基本类库 + JVM，没有JRE，java程序无法运行
     + JDK = JRE+JVM+开发工具包
     + Java核心优势:一次编译，到处运行，能够跨平台运行的核心在于 JVM
5. ![image-20200706212354459](/Users/markhiggins/Desktop/java/image-20200706212354459.png)

## 第三节  概念理解⾯向对象编程和特点

1. 什什么是⾯面向对象编程

   维基百科：

   ⾯向对象程序设计（英语：Object-oriented programming，缩写：OOP）是种具有对象概念的程序编程典范，同时也是⼀种程序开发的抽象⽅针。可能包含数据、属性、代码与⽅法。对象则指的是类的实例！！！。它将对象作为程序的基本单元，将程序和数据封装其中，以提⾼软件的重⽤用性、灵活性和扩展性，对象里的程序可以访问及经常修改对象相关连的数据。在⾯向对象程序编程⾥	，计算机程序会被设计成彼此相关的对象。

   * 什什么是⾯面向过程编程

     * 捕捉⽼老老⿏鼠

       * 买老⿏笼

       * 放诱饵

       * 等老鼠进⼊笼⼦

       * 把笼⼦子关起来

   * 什么是面向对象编程
     * 我买只猫，猫有抓⽼老鼠的⽅法，对象本身具有的⽅法
     * 放进房⼦⾥里面就行了
     * 复用（放到别的房子⾥面）

2. Java语⾔言念特点

   * 类：就是模板，⽤来定义⼀一类对象的⽅方法和属性，⽐比如⼈人、学⽣生、猫，万物都是有模板，都是可以定义为类。 (类名首字母大写)

   ```java
   class Student {
     
   }
   
   class Person {
     
   }
   
   class Cat {
     
   }
   ```

   * 对象：类的实例化，⽐如 学生这个类实例化，就是 XX同学

   ```java
   Student student = new Student();
   Cat cat1 = new Cat();
   new Persion();
   ```

   * ⽅法：类的⾏为属性，⽐如学⽣这个类，有吃饭，学习，睡觉；猫这个类，可以抓老鼠

   ```java
   class Student {
   	//定义⼀一个吃饭的⽅方法
   	public void eat(){
   	}
   	//定义⼀一个睡觉的⽅方法
   	public void sleep(){
   	}
   }
   ```

   * 属性：⽐如学⽣都有年龄，姓名等属性(⾯向过程的时候，一般叫变量；⾯向对象编程，一般就叫属性)
     * 参数：外部传递过来的叫参数
     * 变量：除开属性之外的，和除开参数之外，就叫变量

   ```java
   class Student {
     // 定义⼀个年龄的属性
     private int age;
     // 定义⼀个名称的属性
     private String name;
     
     public void set(int age){
   		this.age = age;
   	}
     
     //	定义⼀个吃饭的方法
   	public void eat(){
   	}
     
     //定义⼀个睡觉的方法
   	public void sleep(){
   	}
   }
   ```

# 第二章  Java开发环境准备和基础语法(一)

## 第一节  CMD和VSCODE工具安装、环境变量介绍使⽤

* VSCODE工具：⽂本⼯具，⾃带⽂本⼯具不⽅便

* CMD： 命令操作工具，window命令工具

  * 打开⽅式 win + r ->cmd
  * DOS命令（⾃学）

* 环境变量：

  * 什么是环境变量：环境变量是在操作系统中⼀个具有特定名字的对象，它包含了一个或者多个应⽤程序所将使用到的信息。例如Windows和DOS操作系统中的path环境变量，当要求系统运⾏一个程序而没有告诉它程序所在的完整路径时，系统除了在当前⽬录下⾯寻找此程序外，还应到path中指定的路径去找。用户通过设置环境变量，来更好的运行进程。

  * 不能理理解？？？？

    就是告诉计算机去这个路路径下找对应的文件

* 为什么要配置Java环境变量

  * ⽅便编译，运行java程序，不然就要进到对应的目录才可以执行

* JDK8下载

  * <https://www.oracle.com/java/technologies/javase/javase-jdk8-downloads.html>
  * 不能访问的话，就是官方改版，官⽅会有其他路径

## 第二节  Java环境变量配置

* win10怎么配置环境变量

  * 右键 此电脑 ->（属性） ->（⾼级系统设置） ->（环境变量）

* 新建三个变量

  * JAVA_HOME    **变量量值为JDK安装路路径**
  * PATH  **%JAVA_HOME%\bin**
  * CLASSPATH  **.;%JAVA_HOME%\lib\dt.jar;%JAVA_HOME%\lib\tools.jar;**

* 环境变量安装

  1. 打开配置路径

     ![image-20200706220607803](/Users/markhiggins/Desktop/java/image-20200706220607803.png)

     ***

     ![image-20200706220739325](/Users/markhiggins/Desktop/java/image-20200706220739325.png)

     ***

     ![image-20200706220832733](/Users/markhiggins/Desktop/java/image-20200706220832733.png)

     **【注意：Path路路径新增这个即可】**

     ***

     ![image-20200706220925279](/Users/markhiggins/Desktop/java/image-20200706220925279.png)

  2. 验证环境变量是否成功

     分别输⼊入下⾯3个命令，不报错即可

     * javac
     * java
     * java -version

## 第三节  Hello World

```java
public class HelloWorld{
	public static void main(String [] args){
		System.out.println("HelloWorld....fujitsu");
	}
}
```

* 完成代码
* 保存⽂件，通过CMD窗口进⼊对应的路径
* 编译 javac HelloWorld.java
* 运行 java HelloWorld

**【注意事项：需要配置电脑显示隐藏⽂件夹的后缀，不然容易进坑】**

## 第四节  Hello World程序剖析Java语法

###  基础语法：

* java⽂件名：⽂件名必须和类名相同，后缀为.java； 否则会出错
* 类class：表示声明⼀个类，类名的⾸字⺟需要⼤写，多个单词的话需要使用驼峰形式
  * HelloWorld、UserAccount、User
* ⽅法：⽅法名需要小写字母开头，若有⼏个单词，则后续的采用驼峰形式
* 主方法：固定搭配，需要硬记，所有程序的主⼊口 `public static void main(String [] args)`
* 所有变量、名称都是⼤小写敏感的！！！！

# 第三章  集成开发环境



# 第四章  Java开发环境准备和基础语法(二) 

## 第一节  Java程序的标识符和关键字

* 什么是标识符：java程序的组成，⽐如类名、⽅法名、变量名等

  注意点： * 标识符可以由字母、数字、下划线_ 、美元符（$）组成，但不能包含%，空格等其他

  特殊字符，不能以数字开头 * 区分⼤小写 * 不能是java关键字

  ```
  * 合法的标识符：age, User, _Student, $Boy, _1_value
  * 不合法的标识符：#age, 8User, my friend, class, if
  ```

* 什么是Java关键字： 是电脑语⾔里事先定义的，有特别意义的标识符，有时⼜叫保留字，关键字

  不能⽤作变量名、⽅法名、类名、包名和参数

  ```
  boolean、byte、char、double、enum、float、int、long、short、void
  private、protected、public、default 
  abstract、extends、class、interface、return、static、super
  assert、break、case、try、catch、const、continue、do、else、final、finally、
  for、goto、if、implements、import
  instanceof、native、new、package
  switch、synchronized 、this、throw、throws
  transient、volatile、while
  ```

## 第二节  java核⼼基础知识之修饰符

* 修饰符的作用是啥？⽤来定义类、⽅法或者变量的访问权限
* 两大类
  * 访问修饰符：限定类、属性或⽅法是否可以被程序⾥的其他部分访问和调用的修饰符
  * `private < default < protected < public`
  * ⾮访问修饰符：⽤来修饰或者辅助功能。例如`static、final、abstract、synchronized`等

* 主要记住：
  * 外部类修饰符： public或者为默认
  * ⽅法、属性修饰符：`private、default、protected、public`
    1. `public` - 公开对外部可⻅
    2. `protected `- 对包和所有⼦类可⻅
    3. `private` - 仅对类内部可⻅
* ⽅法级

|  修饰符   | 当前类 | 同一包内 | 不同包中的子类 | ⼦类(不不同包) |
| :-------: | :----: | :------: | :------------: | :------------: |
|  public   |   Y    |    Y     |       Y        |       Y        |
| Protected |   Y    |    Y     |       Y        |       N        |
|  default  |   Y    |    Y     |       N        |       N        |
|  Private  |   Y    |    N     |       N        |       N        |

* java修饰符和使⽤场景

  * 主要记住：

    * ⽅法、属性修饰符：`private、default、protected、public`
      * `public` - 公开对外部可⻅
      * `protected `- 对包和所有⼦类可⻅
      * `private `- 仅对类内部可⻅

  * 属性或者成员变量，都⽤`private`修饰，不用其他的，这个是java开发的约束

  * Java中`public class`与`class`的区别

    * 在一个`*.java`的文件中，只能有一个`public class`的声明，有多个`public则`编译报错，其类名称必须与⽂件名称完全一致,但是允许有多个class的声明

      ```java
      public class A{
      	public static void main(String [] args){
      		System.out.println("A");
      	}
      };
      class B{};
      class C{};
      ```

    * 只有`public`修饰的类，才能在包外部包可见；否则只是包内私有的类，类不能被其他包访问。

  

## 第三节  Java核心基础之数据类型

* 计算机基础知识
  * bit 位 ,即0或者1, 0101010110
  * byte字节，8位作为一个字节，字节是处理数据的基本单位
  * 1 byte = 8 bits
  * 1 KB = 1024 bytes
  * 1 MB = 1024 KB
  * 1 GB = 1024 MB
* 八种基本数据类型（每个数据都需要从计算机内存中申请空间，来存储它）
  1. byte
     * 8位
     * 最⼤127，最小-128
     * 节省空间，占用`int`类型的四分之⼀
     * 默认 0
  2. short
     * 16位
     * 最小-32768，最大32767
     * `int`类型的二分之⼀
     * 默认是0
  3. int
     * 32位
     * 最小 -2147483648，最大 2147483647
     * 整数默认是`int`类型
     * 默认是0
  4. long
     * 64位
     * 最小 -9223372036854774808，最大 9223372036854774807
     * 默认是 0L
  5. float 浮点
     * 单精度32位
     * 默认0.0f
  6. double
     * 双精度 64位
     * 浮点数默认位`double`类型
     * 默认是0.0
  7. boolean
     * 1位
     * true或者false
     * 默认是false
  8. char
     * 16位的 unicode字符，即两个字节表示⼀个字符
     * 最⼩是 `\u0000 `即0，最大` \ufff `即65535
     * 例子 char demo = 'A'
  9. 类型转换 `double > float > long > int > short > byte`  ⼩转换到大，可以直接转换，而从大到⼩，需要强制转，会有精度丢失

* 引⽤数据类型：`Class`创建的对象 或者 数组都是引用数据类型
  * `String `：字符串对象，也是引⽤数据类型

##  第四节  java核⼼基础之数组

* 场景：需要声明 0~99，100个整数

  ```java
  int i=0;
  int i1=1;
  ...
  int i99 = 100;
  ```

* 什么是数组

  * ⼀种数据结构，⽤来存储同一类型之的集合

  * 通过⼀个整形下标可以访问数组中的每一个值, 从0开始计算，记住，特别重要

  * 内存中存储相同数据类型的连续的空间

    <img src="/Users/markhiggins/Desktop/java/image-20200706230126706.png" alt="image-20200706230126706" style="zoom:150%;" />

* 使⽤数组

  * 声明数组变量时，需要指出数据类型和数组变量的名字

    ```java
    //声明数组，但没有初始化
    int [] numbers;
    //使用new运算符创建数组
    int [] numbers2 = new int[100];
    ```

  * `new int[n]`将会创建⼀个⻓度为`n`的数组

    ```java
    //可以使⽤用这两种形式声明数组,推荐第一种
    int [] numbers;
    int numbers2 [];
    ```

* 数组初始化和匿名数组

  ```java
  //初始化，数组的⼤小就是初始值的个数
  int[] numbers = { 1,2,3,4,5,6 };
  //匿名数组
  new int[] { 1,2,3,4,5,6 };
  ```

* 注意：

  1. 所有元素都初始化为0，boolean数组的元素会初始化为false
  2. ⼀旦创建了了数组，就不能改变它的⼤小
  3. 数组需要初始化才可以操作，不能索引越界

* 拓展

  * 上述的是⼀维数组

    ```java
    int [] numbers = {1,2,3};
    String[] str=new String[2];
    String[] str= {"apple", "cat", "dog"};
    ```

  * 多维数组

    ```java
    //创建并初始化
    int [][] numbers = {[1,2,3],[4,5,6],[7,8,9]}
    //创建
    int [][] numbers2 = new int[3][3];
    ```

* 数组⾥面有很多⽅方法，是自带的方法和属性

  * 获取数组长度的属性名称 length，使⽤就是 数组名`.length`

## 第五节  Java内存空间堆栈

## 第六节  Java核⼼基础之变量类型

1. 类变量(静态变量)：

   * 使⽤用static声明的变量，可以直接使用 类名.变量名访问
   * 一个类不管创建了多少个对象，类只拥有类变量的⼀份拷贝，数值默认值是0，布尔型默认值是false，引⽤用类型默认值是null
   * ⽣命周期
     * 在第⼀次被访问时创建，在程序结束时销毁
   * 声明为public类型，一般这样声明 public static final
   * 存储在⽅法区，和堆栈不一样的一个空间

   ```java
   public class Student{
   		public static final String PREFIX = "我是叫";
   }
   ```

2. 实例变量(属性)

   * 需要使⽤对象.变量名才可以访问
   * 对象被实例化之后，实例例变量的值就跟着确定，可以是赋值，也可以是默认值
   * ⽣命周期
     * 在对象创建的时候创建，在对象被销毁的时候销毁
   * 访问修饰符可以修饰实例变量，一般是私有的，private修饰，然后通过方法来进行查看或者修改

   ```java
   public class Student {
   	//介绍前缀
   	public static final String PREFIX = "我是叫";
   	//年年龄
   	private int age;
   	//姓名
   	private String name;
   	public int getAge() {
   		return age;
   	}
   	public void setAge(int age) {
   		this.age = age;
   	}
   	public String getName() {
   		return name;
   	}
   	public void setName(String name) {
   		this.name = name;
   	}
   }
   ```

3. 局部变量

   * ⽅法中的变量
   * 声明在⽅法、构造方法、语句块、形式参数等
   * ⽣命周期
     * 当它们执⾏完成后，变量将会被销毁
   * 访问修饰符不能⽤于局部变量
   * 局部变量没有初始值，必须初始化后才可以被使⽤

   ```java
   public class Student {
   	//介绍前缀
   	public static final String PREFIX = "我是叫";
   	
   	//年年龄
   	private int age;
   	
   	//姓名
   	private String name;
   	public int getAge() {
   		return age;
   	}
   	public void setAge(int age) {
   		this.age = age;
   	}
   	public String getName() {
   		return name;
   	}
   	public void setName(String name) {
   		this.name = name;
   	}
   	//⾃自我介绍⽅方法
   	public String introduce(){
   		String content = PREFIX + name + "，年年龄是" + age;
   		return content;
   	}
   }
   
   ```

## 第七节  ⽅法入参和返回值

1. ⽅法入参和返回类型

   * ⽅法⼊参

     * 基础数据类型

     * 引⽤数据类型

       ```java
       修饰符 返回类型 ⽅法名(参数类型 参数名,参数类型 参数名...){
       	//⽅方法体
       		return
       }
       ```

   * ⽅法返回类型

     * return xxx 具体类型

     * 如果不用返回，则⽅法返回类型上写 void

       ```java
       修饰符 void ⽅方法名(参数类型 参数名,参数类型 参数名...){
       		//⽅方法体
       }
       ```

     

## 第八节  Java核心之基础运算符

1. 算术运算符:

   ```
   加法 +
   减法 -
   乘法 *
   除法 /
   取余 %
   ```

   ***

   ```
   ⾃自增1 ++
   a++ 就是 a=a+1
   ⾃自减1 --
   a-- 就是 a=a-1
   int a = 5;
   int b = a++;
   int c = ++a;
   int d = a--;
   int e = --a;
   ```

   * 注意
     * 自增（++）自减（--）运算符是一种特殊的算术运算符
     * ⾃增（++）⾃减（--）在变量左右有不同的意义
       *  在变量左边则先自增减操作，再进⾏表达式运算
       * 在变量右边则先进⾏表达式运算，在进⾏自增减操作
     * ⾃增和⾃减运算符只能⽤于操作变量，不能直接⽤于操作数值或常量

2. 关系运算符（⽤于数值的⽐较，不能是字符串等其他⾮数值）

   ```
   等号 ==
   不不等 !=
   ⼤大于 >
   ⼤大于或等于 >=
   ⼩小于 <
   ⼩小于或等于 <=
   ```

3. 逻辑运算符

   * 逻辑与 `&&`
     * 仅当两个操作数都为真，条件才为真
     * 有短路作⽤
   * 逻辑或` ||`
     * 任何两个操作数任何⼀个为真，条件为真
     * 有短路作⽤
   * 逻辑⾮ `！`
     * 反转操作数，如果条件为true，则逻辑⾮运算符将得到false

4. 赋值运算符

   ```java
   赋值 =
   加和赋值 + =
   减和赋值 - =
   乘和赋值 * =
   除和赋值 / =
   int a=5;
   int c=10;
   // c=c+a;
   c +=a;
   //c =c-a;
   c -=a;
   //c =c*a;
   c *=a;
   //c=c/a
   c /=a;
   ```

5. 三⽬运算符

   ```
   格式
   	条件 ? 成功 : 否则
   例子
   	int age =5;
   	age > 18: "成年": "未成年"
   ```

6. 运算符优先级

   * 和数学运算一样，可以加括号控制优先级
     * 乘除取余 `* / %`
     * 加减 `+ -`
     * 关系运算`>, >=, <,<=`
     * 相等 `==、!=`
     * 逻辑与 `&&`
     * 逻辑或 `||`
     * 三⽬运算 `? :`
     * 赋值 `=`

# 第五章  Java基础语法进阶(循环分支结构)

## 第一节 循环

1. 原先代码是顺序结构，只能被执⾏一次，如果同样操作被执⾏多次，就是循环

2. while 循环

   ```java
   //boolean表达式为true则会⼀直执⾏
   while(布尔表达式){
   	//循环执⾏的内容
   }
   ```

3. do…while 循环

   ```java
   do{
   	//循环执⾏行行的内容
   }while(布尔表达式);
   ```

4. while和do while的区别

   * while的话⼀定需要满足条件才会执⾏
   * do while的话，会先执⾏一次循环内容，再判断是否继续执⾏

5. for循环

   * 普通for循环

     ```java
     for(初始化; 布尔表达式; 更新变化条件){
     	//循环执⾏的内容
     }
     //例子
     for(int i=0; i<20;i++){
     	System.out.println(i);
     }
     ```

     ***

     ```java
     * “初始化” 一般是初始化⼀个变量，只执⾏一次，也可以是空语句
     * 接着判断 “布尔表达式”，如果为true，则执⾏循环内容；为false则终⽌止环
     * “更新变化条件” 执⾏循环内容后，更新循环控制变量
     * 再次检测 “布尔表达式”，如果为true，则执⾏循环内容；为false则终⽌循环
     ```

   * 增强for循环

     ```java
     for(声明变量类型：被遍历的集合或者数组){
     	//循环内容
     }
     ```

     * 声明变量类型是局部变量，该变量的类型必须和集合或者数组元素的类型一致

## 第二节  循环退出和跳过

1. 循环退出

   * break 关键字
   * 跳出当前层的循环体，执⾏循环体下⾯的语句
   * 重要：字符串比较是否相等，不能用 ==，应该是用 equals方法

2. 循环跳过

   * continue 关键字
   * 跳过当前循环，执⾏下⼀次循环, (忽略当前循环内容，直接执⾏下⼀次)

3. 多种循环的实现⽅式总结

   * while 循环

     ```java
     while(布尔表达式){
     }
     ```

   * do while循环

     ```java
     do{
     }while(布尔表达式);
     ```

   * 普通for循环

     ```java
     for(初始化; 布尔表达式; 变量更新){
     }
     ```

   * 增强for循环

     ```java
     for(声明变量类型： 集合或者数组){
     }
     ```

## 第三节  If else条件语句

1. if 语句的使⽤

   ```java
   //如果布尔表达式为true，则执行花括号⾥面的内容，如果语句体只有⼀句，则花括号可以不写，但是推荐写
   if(布尔表达式){
   	//语句体
   }
   ```

2. if else 语句的使用，如果if条件为false，则else⾥面的内容会被执行

   ```java
   if(布尔表达式){
   	//语句体
   }else{
   	//语句体
   }
   ```

3. if else if else 语句的使用，⽤于判断多个条件

   ```java
   if(布尔表达式1){
   	//语句体
   }else if(布尔表达式2){
   	//语句体
   }else if(布尔表达式3){
   	//语句体
   }else if(布尔表达式4){
   	//语句体
   }else{
   	//语句体
   }
   ```

4. if else 嵌套

   ```java
   int age = 30;
   if(age > 10){
   	if(age > 18){
   			if(age>25){
   			}else{
   			}
   	}else{
   	}
   }else{
   }
   ```

   















